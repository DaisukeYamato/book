x <- UniformSamples*100
rx <- round(x)+1
ux <- unique(rx)
